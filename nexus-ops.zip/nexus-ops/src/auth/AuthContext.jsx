import { createContext, useContext, useState } from 'react';
import { USERS } from '../data/mock';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);
export const homeFor = (user) => (user?.role === 'FloorManager' ? '/floor' : '/line');

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem('nexus_user')); } catch { return null; }
  });

  // Mock login. Replace with api.post(...) later.
  const login = (email, password) => new Promise((resolve, reject) => setTimeout(() => {
    const u = USERS.find((x) => x.email === email.trim().toLowerCase() && x.password === password);
    if (!u) return reject(new Error('Invalid email or password.'));
    const { password: _p, ...safe } = u;
    localStorage.setItem('nexus_token', 'mock-token');
    localStorage.setItem('nexus_user', JSON.stringify(safe));
    setUser(safe); resolve(safe);
  }, 700));

  const logout = () => { localStorage.clear(); setUser(null); };
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}
