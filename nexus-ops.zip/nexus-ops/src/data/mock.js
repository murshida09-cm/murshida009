import { useEffect, useState } from 'react';

export const LINES = {
  1: ['Machine1', 'Machine2', 'Machine3'],
  2: ['Machine4', 'Machine5', 'Machine6'],
};
export const STATUSES = ['RUNNING', 'STOPPED', 'WAITING', 'BLOCKED'];

// MOCK users. Replace with a FastAPI login call when the contract is ready.
export const USERS = [
  { email: 'line1@nexus.ai', password: 'demo123', name: 'Line 1 Operator', role: 'Line1Operator', line: 1 },
  { email: 'line2@nexus.ai', password: 'demo123', name: 'Line 2 Operator', role: 'Line2Operator', line: 2 },
  { email: 'manager@nexus.ai', password: 'demo123', name: 'Floor Manager', role: 'FloorManager', line: null },
];

const rnd = (a, b) => a + Math.random() * (b - a);
const point = (i) => ({ t: i, sval: +rnd(20, 90).toFixed(1), punits: Math.round(rnd(10, 60)) });
const pickStatus = (prev) => (!prev || Math.random() < 0.15
  ? STATUSES[Math.random() < 0.6 ? 0 : Math.floor(rnd(0, 4))] : prev);

const seed = () => {
  const out = {};
  Object.entries(LINES).forEach(([line, ms]) => ms.forEach((m) => {
    out[m] = { name: m, line: +line, status: pickStatus(), series: Array.from({ length: 24 }, (_, i) => point(i)) };
  }));
  return out;
};

// Simulated live stream. TODO: replace with Axios polling / WebSocket.
export function useMachineStream() {
  const [data, setData] = useState(null);
  useEffect(() => {
    const boot = setTimeout(() => setData(seed()), 500);
    const tick = setInterval(() => setData((d) => {
      if (!d) return d;
      const next = {};
      Object.values(d).forEach((m) => {
        const last = m.series[m.series.length - 1].t + 1;
        next[m.name] = { ...m, status: pickStatus(m.status), series: [...m.series.slice(1), point(last)] };
      });
      return next;
    }), 2000);
    return () => { clearTimeout(boot); clearInterval(tick); };
  }, []);
  return { data, loading: !data };
}
