export default function Logo() {
  return <div className="logo"><div className="logo-mark">N</div><span>Nexus<b>AI</b></span></div>;
}
