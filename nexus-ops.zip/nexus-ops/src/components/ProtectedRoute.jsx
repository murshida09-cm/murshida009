import { Navigate } from 'react-router-dom';
import { useAuth, homeFor } from '../auth/AuthContext';

// Not signed in -> /login; wrong role -> that user's own home screen.
export default function ProtectedRoute({ roles, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={homeFor(user)} replace />;
  return children;
}
