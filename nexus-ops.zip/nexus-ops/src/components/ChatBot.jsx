import { useEffect, useRef, useState } from 'react';
import { MessageSquare, X, Send, Bot, AlertCircle } from 'lucide-react';
import { askAssistant, SUGGESTIONS } from '../api/chat';

export default function ChatBot({ data }) {
    const [open, setOpen] = useState(false);
    const [input, setInput] = useState('');
    const [sending, setSending] = useState(false);
    const [error, setError] = useState('');
    const [messages, setMessages] = useState([
        { role: 'bot', text: 'Hi! I\'m your floor assistant. Ask me about machine status or punits.' },
    ]);
    const endRef = useRef(null);

    useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, sending, open]);

    const send = async (text) => {
        const q = text.trim();
        if (!q || sending) return;
        setError(''); setInput('');
        setMessages((m) => [...m, { role: 'user', text: q }]);
        setSending(true);
        try {
            const reply = await askAssistant(q, data);
            setMessages((m) => [...m, { role: 'bot', text: reply }]);
        } catch {
            setError('Could not reach the assistant. Please try again.');
        } finally { setSending(false); }
    };

    return (
        <>
            {!open && (
                <button className="chat-fab" onClick={() => setOpen(true)} aria-label="Open assistant"><MessageSquare size={24} /></button>
            )}
            {open && (
                <section className="chat fade" aria-label="Floor assistant">
                    <header className="chat-head">
                        <div className="chat-title"><div className="chat-bot"><Bot size={18} /></div>
                            <div><b>Floor Assistant</b><small>Mock data</small></div></div>
                        <button onClick={() => setOpen(false)} aria-label="Close"><X size={18} /></button>
                    </header>
                    <div className="chat-body">
                        {messages.map((m, i) => <div key={i} className={`bubble ${m.role}`}>{m.text}</div>)}
                        {sending && <div className="bubble bot typing"><span /><span /><span /></div>}
                        {error && <div className="error-box"><AlertCircle size={16} />{error}</div>}
                        <div ref={endRef} />
                    </div>
                    <div className="chips">
                        {SUGGESTIONS.map((s) => <button key={s} onClick={() => send(s)} disabled={sending}>{s}</button>)}
                    </div>
                    <form className="chat-input" onSubmit={(e) => { e.preventDefault(); send(input); }}>
                        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about the floor…" />
                        <button disabled={sending || !input.trim()} aria-label="Send"><Send size={18} /></button>
                    </form>
                </section>
            )}
        </>
    );
}