import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Factory, LogOut } from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import Logo from './Logo';

export default function Layout({ eyebrow, title, children }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const isMgr = user.role === 'FloorManager';
  return (
    <div className="shell">
      <aside className="sidebar">
        <Logo />
        <nav className="nav">
          {isMgr
            ? <NavLink to="/floor"><Factory size={18} /> Floor Dashboard</NavLink>
            : <NavLink to="/line"><LayoutDashboard size={18} /> Line {user.line} Dashboard</NavLink>}
        </nav>
        <div className="spacer" />
        <div className="nav"><button onClick={() => { logout(); nav('/login'); }}><LogOut size={18} /> Sign out</button></div>
      </aside>
      <main className="main fade">
        <div className="topbar">
          <div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1></div>
          <div className="who"><div className="avatar" /><div><b>{user.name}</b><br /><span style={{ color: 'var(--text-muted)' }}>{user.role}</span></div></div>
        </div>
        {children}
      </main>
    </div>
  );
}
