const W = 300, H = 150, P = 24;

function Chart({ series, field, yLabel }) {
  const vals = series.map((p) => p[field]);
  const max = Math.max(...vals) * 1.1;
  const x = (i) => P + (i / (series.length - 1)) * (W - P - 8);
  const y = (v) => H - P - (v / max) * (H - P - 10);
  const pts = series.map((p, i) => `${x(i)},${y(p[field])}`).join(' ');
  return (
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${yLabel} over time`}>
      <defs>
        <linearGradient id={`g-${field}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor="#00B8F5" stopOpacity=".35" /><stop offset="1" stopColor="#00B8F5" stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1={P} y1={6} x2={P} y2={H - P} stroke="#10304A" />
      <line x1={P} y1={H - P} x2={W - 8} y2={H - P} stroke="#10304A" />
      <polygon points={`${P},${H - P} ${pts} ${W - 8},${H - P}`} fill={`url(#g-${field})`} />
      <polyline points={pts} fill="none" stroke="#00B8F5" strokeWidth="2" />
      <text x={2} y={12}>{yLabel} ↑</text>
      <text x={W - 50} y={H - 6}>time →</text>
    </svg>
  );
}

// field: 'sval' (raw data, line dashboard) | 'punits' (floor dashboard)
export default function MachineCard({ machine, field, yLabel, showStatus }) {
  return (
    <div className="card">
      <div className="card-head"><span>Graphical Representation</span>
        <b style={{ color: 'var(--text-primary)' }}>{machine.series[machine.series.length - 1][field]}</b></div>
      <Chart series={machine.series} field={field} yLabel={yLabel} />
      {showStatus
        ? <div className={`pill s-${machine.status}`}><i />{machine.name} · {machine.status}</div>
        : <div className="pill" style={{ color: 'var(--text-primary)', borderColor: 'var(--border-subtle)' }}>{machine.name}</div>}
    </div>
  );
}
