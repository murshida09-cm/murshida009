import { LINES } from '../data/mock';
// import api from './client';

const last = (m) => m.series[m.series.length - 1];

// MOCK assistant: answers from the live floor data.
function mockReply(question, data) {
  if (!data) return 'Machine data is still loading. Please try again in a moment.';
  const text = question.toLowerCase();
  const all = Object.values(data);
  const lineMatch = text.match(/line\s*([12])/);
  const scope = lineMatch ? all.filter((m) => m.line === +lineMatch[1]) : all;
  const label = lineMatch ? `Line ${lineMatch[1]}` : 'the floor';

  const wanted = [['STOPPED', /stopped|down|stuck/], ['BLOCKED', /blocked/], ['WAITING', /waiting/], ['RUNNING', /running/]]
    .find(([, re]) => re.test(text));
  if (wanted) {
    const names = scope.filter((m) => m.status === wanted[0]).map((m) => m.name);
    return names.length ? `${wanted[0]} on ${label}: ${names.join(', ')}.` : `No machines are ${wanted[0]} on ${label} right now.`;
  }
  if (/punit|production|output|total|best|top/.test(text)) {
    const sum = scope.reduce((s, m) => s + last(m).punits, 0);
    const top = [...scope].sort((a, b) => last(b).punits - last(a).punits)[0];
    return `Current punits for ${label}: ${sum}. Highest machine: ${top.name} (${last(top).punits}).`;
  }
  if (/status|summary|overview|how/.test(text)) {
    return scope.map((m) => `${m.name}: ${m.status} (${last(m).punits} punits)`).join('\n');
  }
  return 'I can help with machine status (running, stopped, waiting, blocked), punits, and Line 1 / Line 2 summaries. Try one of the suggestions below.';
}

export async function askAssistant(message, data) {
  // TODO: when the API contract is shared, replace with:
  // const res = await api.post('<chat-endpoint>', { message }); return res.data.<reply-field>;
  await new Promise((r) => setTimeout(r, 700));
  return mockReply(message, data);
}

export const SUGGESTIONS = ['Floor summary', 'Which machines are stopped?', 'Total punits', 'Line 2 status'];
export { LINES };