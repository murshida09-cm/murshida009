import axios from 'axios';
// Swap in the real FastAPI base URL once the contract is shared.
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000' });
api.interceptors.request.use((cfg) => {
  const token = localStorage.getItem('nexus_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});
export default api;
