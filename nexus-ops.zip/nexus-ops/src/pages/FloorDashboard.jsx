import { useState } from 'react';
import { LINES, useMachineStream } from '../data/mock';
import Layout from '../components/Layout';
import MachineCard from '../components/MachineCard';
import ChatBot from '../components/ChatBot';

export default function FloorDashboard() {
  const { data, loading } = useMachineStream();
  const [filter, setFilter] = useState('all');
  const lines = filter === 'all' ? Object.keys(LINES) : [filter];
  const total = data ? Object.values(data).reduce((s, m) => s + m.series[m.series.length - 1].punits, 0) : 0;
  return (
    <Layout eyebrow="Floor Manager · All lines" title="Floor Dashboard (punits)">
      <div className="tabs">
        {['all', '1', '2'].map((f) => (
          <button key={f} className={filter === f ? 'on' : ''} onClick={() => setFilter(f)}>{f === 'all' ? 'All lines' : `Line ${f}`}</button>
        ))}
      </div>
      {loading ? <div className="empty">Loading floor data…</div> : (
        <>
          <div className="kpis"><div className="kpi"><small>Current punits</small><div>{total}</div></div>
            <div className="kpi"><small>Machines</small><div>{Object.keys(data).length}</div></div></div>
          {lines.map((l) => (
            <section key={l}>
              <div className="line-title">Line {l} · {LINES[l].join(' → ')}</div>
              <div className="grid">{LINES[l].map((n) => <MachineCard key={n} machine={data[n]} field="punits" yLabel="Punits" />)}</div>
            </section>
          ))}
        </>
      )}
      <ChatBot data={data} />
    </Layout>
  );
}
