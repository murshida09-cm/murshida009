import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { ChevronRight, Lock, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { useAuth, homeFor } from '../auth/AuthContext';
import { USERS } from '../data/mock';
import Logo from '../components/Logo';

export default function Login() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (user) return <Navigate to={homeFor(user)} replace />;

  const submit = async (e) => {
    e.preventDefault(); setError(''); setLoading(true);
    try { nav(homeFor(await login(email, password)), { replace: true }); }
    catch (err) { setError(err.message); setLoading(false); }
  };

  return (
    <div className="login">
      <section className="login-left">
        <Logo />
        <div className="fade">
          <div className="eyebrow">Secure AI workspace</div>
          <h1>Build, explore and operate with AI.</h1>
          <p className="login-sub">A configurable enterprise shell for conversational and agentic AI experiences.</p>
          <div className="orbit" aria-hidden="true">
            <div className="ring" /><div className="ring dashed d1" /><div className="ring dashed d2" />
            <div className="tile"><Sparkles size={38} color="#fff" /></div>
          </div>
        </div>
        <div className="badges">
          <span><Lock size={16} /> Token authentication</span>
          <span><ShieldCheck size={16} /> Role-based access</span>
        </div>
      </section>
      <section className="login-right">
        <Logo />
        <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 8 }}>One workspace. Any AI use case.</p>
        <form className="fade" onSubmit={submit}>
          <h2>Welcome back</h2>
          <p className="sub">Sign in to continue to your workspace.</p>
          {error && <div className="error-box"><AlertCircle size={16} />{error}</div>}
          <div className="field"><label htmlFor="e">Email</label>
            <input id="e" className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" /></div>
          <div className="field"><label htmlFor="p">Password</label>
            <input id="p" className="input" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" /></div>
          <button className="btn-primary" disabled={loading || !email || !password}>
            <span>{loading ? 'Signing in…' : 'Sign in'}</span>{loading ? <div className="spinner" /> : <ChevronRight size={20} />}
          </button>
          <p style={{ marginTop: 20, fontSize: 14, color: 'var(--text-secondary)' }}>New here? <a href="#">Create an account</a></p>
        </form>
        <div className="demo">Demo accounts (password: demo123), click to fill
          {USERS.map((u) => (
            <button key={u.email} type="button" onClick={() => { setEmail(u.email); setPassword(u.password); }}>{u.role}: {u.email}</button>
          ))}
        </div>
      </section>
    </div>
  );
}
