import { useAuth } from '../auth/AuthContext';
import { LINES, useMachineStream } from '../data/mock';
import Layout from '../components/Layout';
import MachineCard from '../components/MachineCard';

const LEGEND = [['GREEN', 'RUNNING', 'running'], ['RED', 'STOPPED', 'stopped'], ['YELLOW', 'WAITING', 'waiting'], ['ORANGE', 'BLOCKED', 'blocked']];

export default function LineDashboard() {
  const { user } = useAuth();
  const { data, loading } = useMachineStream();
  const names = LINES[user.line];
  return (
    <Layout eyebrow={`Line ${user.line} · ${names.join(' → ')}`} title="Line Dashboard (Raw data)">
      <div className="live" style={{ marginBottom: 20 }}>Live (simulated)</div>
      {loading ? <div className="empty">Loading machine data…</div> : (
        <div className="grid">
          {names.map((n) => <MachineCard key={n} machine={data[n]} field="sval" yLabel="Sval" showStatus />)}
        </div>
      )}
      <div className="legend">
        {LEGEND.map(([c, s, k]) => <span key={s}><i style={{ background: `var(--status-${k})` }} />{c} – {s}</span>)}
      </div>
    </Layout>
  );
}
