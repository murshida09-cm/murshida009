import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth, homeFor } from './auth/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Login from './pages/Login';
import LineDashboard from './pages/LineDashboard';
import FloorDashboard from './pages/FloorDashboard';

function Home() { const { user } = useAuth(); return <Navigate to={user ? homeFor(user) : '/login'} replace />; }

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/line" element={<ProtectedRoute roles={['Line1Operator', 'Line2Operator']}><LineDashboard /></ProtectedRoute>} />
        <Route path="/floor" element={<ProtectedRoute roles={['FloorManager']}><FloorDashboard /></ProtectedRoute>} />
        <Route path="*" element={<Home />} />
      </Routes>
    </AuthProvider>
  );
}
