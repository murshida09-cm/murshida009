# Validation report

- Python API/graph/helper tests: 8 passed.
- Frontend SSE/reducer tests: 3 passed.
- Vite production build: passed.
- Browser integration: passed against the real FastAPI and LangGraph runtime with a deterministic TEST-ONLY fake LLM transport.
- Browser coverage: chit-chat without agents; streamed plan and agent states; question popup; dismiss/reload/replay; resume; completed agent retention; final Markdown; thumbs feedback; download; 375px layout without card overflow.
- Backend coverage: SQLite restart/resume; two queued questions; accepted resume recovery; idempotent create; session history; ownership isolation; SSE cursor replay; failure/retry and client error redaction; helper streaming contract; invalid dependency plans.

No live Azure request was made. Deployment credentials, network access, API-version support, model-specific JSON-protocol compliance and real-model output quality must be verified in your environment. Run `python smoke_llm.py` from the configured backend folder for an explicit live connectivity check (incurs model usage).

This is a single-worker development starter, not production authentication or a verified insurance/compliance system.
