import test from 'node:test';
import assert from 'node:assert/strict';
import {consumeSSE} from '../src/api/sse.js';
import {initialRun,reduceEvent} from '../src/state/runReducer.js';

test('SSE handles UTF-8 split across bytes, CRLF, heartbeats and multiline data',async()=>{
 const text=': heartbeat\r\nid: 7\r\nevent: update\r\ndata: {"type":"answer.delta",\r\ndata: "text":"Hello 世界"}\r\n\r\n';
 const bytes=new TextEncoder().encode(text);let index=0;
 const stream=new ReadableStream({pull(c){if(index===bytes.length)c.close();else c.enqueue(bytes.slice(index,index+=1))}});
 const response=new Response(stream,{headers:{'Content-Type':'text/event-stream'}}),events=[];
 await consumeSSE(response,e=>events.push(e));
 assert.deepEqual(events,[{id:7,type:'answer.delta',text:'Hello 世界'}]);
});
test('Reducer ignores duplicate replay and restores checkpointed agents',()=>{
 let r=initialRun('test');r=reduceEvent(r,{id:1,type:'answer.delta',text:'old partial'});
 r=reduceEvent(r,{id:2,type:'run.started',committed:{mode:'workflow',plan:[{id:'data',name:'Data Agent'},{id:'writer'}],outputs:{data:'done'}}});
 assert.equal(r.answer,'');assert.equal(r.agents[0].status,'done');assert.equal(r.agents[1].status,'waiting');
 const old=r;r=reduceEvent(r,{id:2,type:'answer.delta',text:'duplicate'});assert.equal(r,old);
 r=reduceEvent(r,{id:3,type:'run.paused',interrupts:[{interrupt_id:'q',question:'Country?'}]});assert.equal(r.status,'paused');
 r=reduceEvent(r,{id:4,type:'run.completed',text:'Final'});assert.equal(r.answer,'Final');assert.deepEqual(r.pending,[]);
});
test('Reducer keeps parallel agent output separate',()=>{
 let r=initialRun('test');let id=0;
 for(const agent of [{id:'data'},{id:'regulation'}])r=reduceEvent(r,{id:++id,type:'agent.planned',agent});
 r=reduceEvent(r,{id:++id,type:'agent.delta',agent_id:'data',text:'A'});
 r=reduceEvent(r,{id:++id,type:'agent.delta',agent_id:'regulation',text:'B'});
 assert.equal(r.agents[0].output,'A');assert.equal(r.agents[1].output,'B');
});
