# Configurable AI Workspace UI

## Run
1. `npm install`
2. Set `VITE_API_BASE_URL` if the backend is not `http://localhost:8000`.
3. `npm run dev`

All branding, wording, navigation labels, admin menu labels, endpoint paths, and theme colors are in `src/config/UIConfig.js`.

## Authentication contract
- `POST /api/login` body: `{ email, password }`; response may return `key`, `token`, or `access_token`.
- `POST /api/signup` body: `{ first_name, last_name, email, password }`.
- `GET /api/me` with `Authorization: Bearer <key>`.
- Every subsequent request includes the same Bearer token and the existing `X-Workspace-ID` header.

## Admin contract
- `GET /api/all_users` returns an array, or `{ users: [] }`.
- `POST /api/update_user` body: `{ user_id, role, first_name, last_name }`.

## Existing chat integration
The chat run base endpoint remains `/api/runs`. The UI expects SSE at `/api/runs/{runId}/events`, resume at `/api/runs/{runId}/resume`, and retry at `/api/runs/{runId}/retry`, matching the existing run-stream pattern.

## Admin modules

### Model price card
- `GET  /api/get_price_card` → `[{ mpc_seq_id, llm, input_rate, output_rate }]` (USD per 1M tokens)
- `POST /api/add_price_card` body `{ llm, input_rate, output_rate }`
- `POST /api/update_price_card` body `{ mpc_seq_id, llm, input_rate, output_rate }`
- `POST /api/delete_price_card` body `{ mpc_seq_id }`

The add, update and delete paths are configurable in `UIConfig.api` (`addPriceCard`, `updatePriceCard`, `deletePriceCard`). Change them there if your backend uses different paths.

### Observability
- `GET /api/get_price_card`
- `GET /api/get_observability_data?month=NOV-2026` → `[{ od_seq_id, user, session_id, agent, llm, input_token, output_toke }]`

Everything else is calculated in `src/utils/usage.js`:
- Cost per row = `input_token / 1,000,000 × input_rate + output_token / 1,000,000 × output_rate`
- LLM names are matched without regard to case, spaces or punctuation, so `GPT-4.1`, `gpt4.1` and `GPT 4.1` are treated as the same model.
- Models with no price-card entry are excluded from cost totals, listed in a warning banner, and marked with `*`.
- `output_toke`, `output_token` and `output_tokens` are all accepted.
