// SSE over fetch permits a workspace header; native EventSource cannot set it.
// The wire protocol is standard text/event-stream, not NDJSON or WebSockets.
export async function consumeSSE(response,onEvent,signal){
 if(!response.ok)throw new Error(`Stream request failed (${response.status})`);
 if(!response.headers.get('content-type')?.includes('text/event-stream'))throw new Error('Expected an SSE response');
 const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',data=[],id='';
 function line(value){
  if(value===''){if(data.length){onEvent({...JSON.parse(data.join('\n')),id:Number(id)});data=[]}id='';return}
  if(value.startsWith(':'))return;
  const colon=value.indexOf(':'),field=colon<0?value:value.slice(0,colon);let content=colon<0?'':value.slice(colon+1);if(content.startsWith(' '))content=content.slice(1);
  if(field==='data')data.push(content);else if(field==='id')id=content;
 }
 try{
  while(!signal?.aborted){
   const {done,value}=await reader.read();buffer+=decoder.decode(value||new Uint8Array(),{stream:!done});
   let index;
   while((index=buffer.search(/[\r\n]/))>=0){
    if(buffer[index]==='\r'&&index===buffer.length-1&&!done)break;
    const width=buffer[index]==='\r'&&buffer[index+1]==='\n'?2:1;line(buffer.slice(0,index));buffer=buffer.slice(index+width);
   }
   if(buffer.length>1000000)throw new Error('SSE frame too large');
   if(done)break;
  }
 }finally{await reader.cancel().catch(()=>{});reader.releaseLock()}
}
