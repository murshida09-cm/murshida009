import UIConfig from "../config/UIConfig";
export const API_BASE = (
  import.meta.env.VITE_API_BASE_URL || "http://localhost:8000"
).replace(/\/$/, "");
const TOKEN_KEY = "ai-workspace-token",
  WORKSPACE_KEY = "ai-workspace-id";
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) =>
  token
    ? localStorage.setItem(TOKEN_KEY, token)
    : localStorage.removeItem(TOKEN_KEY);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);
export function workspaceId() {
  let id = localStorage.getItem(WORKSPACE_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(WORKSPACE_KEY, id);
  }
  return id;
}
export function headers(extra = {}) {
  const token = getToken();
  return {
    "Content-Type": "application/json",
    "X-Workspace-ID": workspaceId(),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...extra,
  };
}
async function parse(response) {
  const type = response.headers.get("content-type") || "";
  const value = type.includes("application/json")
    ? await response.json()
    : await response.text();
  if (!response.ok) {
    const detail =
      value?.detail ||
      value?.message ||
      value ||
      `API request failed (${response.status})`;
    const error = new Error(
      typeof detail === "string" ? detail : JSON.stringify(detail),
    );
    error.status = response.status;
    throw error;
  }
  return value;
}
export async function request(path, body, options = {}) {
  const response = await fetch(API_BASE + path, {
    method: options.method || (body === undefined ? "GET" : "POST"),
    headers: headers(options.headers),
    body: body === undefined ? undefined : JSON.stringify(body),
    signal: options.signal,
  });
  return parse(response);
}
export async function login(email, password) {
  const data = await request(UIConfig.api.login, { email, password });
  const token = data.key || data.token || data.access_token;
  if (!token) throw new Error("Login succeeded but no key was returned.");
  setToken(token);
  return token;
}
export async function signup(payload) {
  return request(UIConfig.api.signup, payload);
}
export async function me() {
  return {
    id: 1,
    first_name: "Dev",
    last_name: "User",
    email: "dev@example.com",
    role: "admin", // match whatever your role-based access expects
  }
}
