export function initialRun(id){return {id,status:'queued',mode:null,agents:[],answer:'',pending:[],cursor:0,orchestrator:'Understanding your request',planReady:false,error:null}}
export function reduceEvent(previous,event){
 const run={...previous};if(event.id<=run.cursor)return previous;run.cursor=event.id;
 const updateAgent=(id,fn)=>{run.agents=run.agents.map(a=>a.id===id?fn({...a}):a)};
 switch(event.type){
 case 'run.started':{
  const c=event.committed||{};run.status='running';run.orchestrator='Coordinating workflow';run.mode=c.mode;run.answer=c.final||'';run.pending=[];run.error=null;run.planReady=!!c.plan?.length;
  run.agents=(c.plan||[]).map(a=>({...a,status:c.outputs?.[a.id]?'done':'waiting',output:c.outputs?.[a.id]||'',progress:'',transient:'',updated:0}));break;
 }
 case 'route':run.mode=event.mode;break;
 case 'orchestrator.status':run.orchestrator=event.text;break;
 case 'agent.planned':run.agents=[...run.agents.filter(a=>a.id!==event.agent.id),{...event.agent,status:'waiting',output:'',transient:'',progress:'',updated:0}];break;
 case 'plan.ready':run.planReady=true;run.agents=event.agents.map(a=>({...run.agents.find(x=>x.id===a.id),...a}));break;
 case 'agent.status':updateAgent(event.agent_id,a=>({...a,status:event.status,progress:event.text,transient:event.status==='running'?'':a.transient,output:event.status==='running'?'':a.output}));break;
 case 'agent.progress':updateAgent(event.agent_id,a=>({...a,progress:event.text,transient:event.text,updated:Date.now()}));break;
 case 'agent.delta':updateAgent(event.agent_id,a=>({...a,output:(a.output||'')+event.text,transient:((a.output||'')+event.text).slice(-240),updated:Date.now()}));break;
 case 'answer.delta':run.answer+=event.text;break;
 case 'run.paused':run.status='paused';run.pending=event.interrupts;run.orchestrator='Waiting for your input';break;
 case 'run.completed':run.status='completed';run.answer=event.text;run.pending=[];run.orchestrator='Workflow completed';break;
 case 'run.error':run.agents=run.agents.map(a=>a.status==='running'?{...a,status:'error'}:a);run.status='error';run.error=event.message;run.orchestrator='Run stopped';break;
 }
 return run;
}
