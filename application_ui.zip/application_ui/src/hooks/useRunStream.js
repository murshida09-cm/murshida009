import {useCallback,useEffect,useReducer,useRef,useState} from 'react';
import {API_BASE,headers,request} from '../api/client';
import {consumeSSE} from '../api/sse';
import {initialRun,reduceEvent} from './runReducer';
export default function useRunStream(runId){
 const [run,dispatch]=useReducer(reduceEvent,runId,initialRun),[connection,setConnection]=useState('connecting'),abortRef=useRef();
 const connect=useCallback(async()=>{abortRef.current?.abort();const controller=new AbortController();abortRef.current=controller;setConnection('connecting');try{const response=await fetch(`${API_BASE}/api/runs/${runId}/events`,{headers:headers({'Accept':'text/event-stream'}),signal:controller.signal});setConnection('connected');await consumeSSE(response,event=>dispatch(event),controller.signal);if(!controller.signal.aborted)setConnection('offline')}catch(error){if(!controller.signal.aborted)setConnection('offline')}},[runId]);
 useEffect(()=>{connect();return()=>abortRef.current?.abort()},[connect]);
 const resume=(interrupt_id,answer)=>request(`/api/runs/${runId}/resume`,{interrupt_id,answer});
 const retry=()=>request(`/api/runs/${runId}/retry`,{});
 return {run,connection,resume,retry,reconnect:connect};
}
