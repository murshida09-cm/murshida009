import UIConfig from '../config/UIConfig';

const MONTHS = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];

/** "2026-11" (input[type=month]) -> "NOV-2026" (API format) */
export function toApiMonth(value) {
  const [year, month] = (value || '').split('-');
  return MONTHS[Number(month) - 1] ? `${MONTHS[Number(month) - 1]}-${year}` : '';
}
export function currentMonthValue() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

/** Model names are matched case/format-insensitively: "GPT-4.1", "gpt4.1", "GPT 4.1" are the same model. */
export const modelKey = name => String(name || '').toLowerCase().replace(/[^a-z0-9]/g, '');

export function buildPriceIndex(priceCard) {
  const index = new Map();
  (priceCard || []).forEach(p => index.set(modelKey(p.llm), { input: Number(p.input_rate) || 0, output: Number(p.output_rate) || 0 }));
  return index;
}

/** cost = input/1M * input_rate + output/1M * output_rate. Returns null when the model has no price. */
export function costFor(index, llm, input, output) {
  const rate = index.get(modelKey(llm));
  if (!rate) return null;
  return (input / 1e6) * rate.input + (output / 1e6) * rate.output;
}

const outputOf = r => Number(r.output_token ?? r.output_toke ?? r.output_tokens ?? 0) || 0;
const inputOf = r => Number(r.input_token ?? r.input_tokens ?? 0) || 0;

function bucket() { return { input: 0, output: 0, cost: 0, unpriced: false }; }
function add(b, input, output, cost) { b.input += input; b.output += output; if (cost === null) b.unpriced = true; else b.cost += cost; }

/** Derives every dashboard figure from the raw observability rows + price card. */
export function aggregate(rows, priceCard) {
  const index = buildPriceIndex(priceCard);
  const totals = bucket(), users = new Map(), agents = new Set(), unpricedModels = new Set();

  for (const r of rows || []) {
    const input = inputOf(r), output = outputOf(r);
    const cost = costFor(index, r.llm, input, output);
    if (cost === null) unpricedModels.add(r.llm);
    const userName = r.user || 'Unknown', session = r.session_id || 'unknown-session';
    const agent = r.agent || 'Unknown agent', llm = r.llm || 'Unknown model';
    agents.add(agent);
    add(totals, input, output, cost);

    if (!users.has(userName)) users.set(userName, { user: userName, ...bucket(), models: new Map(), sessions: new Map() });
    const u = users.get(userName); add(u, input, output, cost);

    if (!u.models.has(llm)) u.models.set(llm, { llm, ...bucket() });
    add(u.models.get(llm), input, output, cost);

    if (!u.sessions.has(session)) u.sessions.set(session, { session_id: session, ...bucket(), firstSeq: r.od_seq_id ?? 0, lines: new Map() });
    const s = u.sessions.get(session); add(s, input, output, cost);
    const lineKey = `${agent}\u0000${llm}`;
    if (!s.lines.has(lineKey)) s.lines.set(lineKey, { agent, llm, ...bucket() });
    add(s.lines.get(lineKey), input, output, cost);
  }

  const userList = [...users.values()].map(u => ({
    ...u,
    models: [...u.models.values()].sort((a, b) => b.cost - a.cost),
    sessions: [...u.sessions.values()].map(s => ({ ...s, lines: [...s.lines.values()], agentCount: new Set([...s.lines.values()].map(l => l.agent)).size })).sort((a, b) => b.firstSeq - a.firstSeq),
  })).sort((a, b) => b.cost - a.cost);

  return { totals, users: userList, userCount: users.size, agentCount: agents.size, unpricedModels: [...unpricedModels] };
}

const nf = new Intl.NumberFormat('en-US');
export const fmtTokens = n => nf.format(Math.round(n || 0));
export function fmtCompact(n) {
  return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 2 }).format(n || 0);
}
export function fmtCost(n, decimals = UIConfig.currency.decimals) {
  if (n === null || n === undefined) return '—';
  return `${UIConfig.currency.symbol}${Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: decimals })}`;
}
export const toList = data => (Array.isArray(data) ? data : data?.items || data?.data || []);
