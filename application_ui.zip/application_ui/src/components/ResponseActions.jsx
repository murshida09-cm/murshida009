import React,{useState,useEffect,useRef} from 'react';
import Icon from './Icon';
export default function ResponseActions({text,feedback,onFeedback,stamp,storageKey}){
 const [copied,setCopied]=useState(false),[error,setError]=useState(''),[localVote,setLocalVote]=useState(()=>{try{return storageKey?localStorage.getItem(storageKey):null}catch{return null}});
 useEffect(()=>{if(storageKey){try{if(localVote)localStorage.setItem(storageKey,localVote);else localStorage.removeItem(storageKey)}catch{}}},[localVote,storageKey]);
 const timer=useRef(null), vote=onFeedback?feedback:localVote;
 useEffect(()=>()=>clearTimeout(timer.current),[]);
 async function copy(){
  setError('');
  try{
   if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text||'')}
   else{
    const previous=document.activeElement,field=document.createElement('textarea');
    field.value=text||'';field.setAttribute('readonly','');field.style.cssText='position:fixed;left:-9999px;top:0';document.body.appendChild(field);field.select();
    let ok=false;try{ok=document.execCommand('copy')}finally{field.remove();previous?.focus()}
    if(!ok)throw new Error('Copy unavailable');
   }
   setCopied(true);clearTimeout(timer.current);timer.current=setTimeout(()=>setCopied(false),2000);
  }catch{setCopied(false);setError('Could not copy. Please select and copy the response.');}
 }
 function rate(value){if(onFeedback)onFeedback(value);else setLocalVote(v=>v===value?null:value)}
 return <div className="response-footer">
  <div className="response-actions" role="group" aria-label="Response actions">
   <button type="button" className={'response-action '+(copied?'selected':'')} onClick={copy} aria-label={copied?'Response copied':'Copy response'} title={copied?'Copied':'Copy response'}><Icon name={copied?'check':'copy'} size={16}/></button>
   <button type="button" className={'response-action '+(vote==='up'?'selected':'')} aria-pressed={vote==='up'} onClick={()=>rate('up')} aria-label="Helpful response" title="Helpful"><Icon name="thumbup" size={16}/></button>
   <button type="button" className={'response-action '+(vote==='down'?'selected':'')} aria-pressed={vote==='down'} onClick={()=>rate('down')} aria-label="Not helpful response" title="Not helpful"><Icon name="thumbdown" size={16}/></button>
  </div>
  <span className="response-action-feedback" role="status">{error|| (copied?'Copied':vote?'Feedback saved in this browser':'')}</span>
  {stamp&&<span className="response-stamp">{stamp}</span>}
 </div>
}
