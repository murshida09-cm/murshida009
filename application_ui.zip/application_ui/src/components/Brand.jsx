import React from 'react';import UIConfig from '../config/UIConfig';
export default function Brand({compact=false}){return <div className={'brand '+(compact?'compact':'')}><span className="brand-mark">{UIConfig.brand.logoText}</span><div><strong>{UIConfig.brand.name}<b>{UIConfig.brand.accent}</b></strong>{!compact&&<small>{UIConfig.brand.tagline}</small>}</div></div>}
