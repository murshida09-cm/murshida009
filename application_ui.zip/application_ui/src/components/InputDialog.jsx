import React,{useEffect,useRef,useState} from 'react';
import Icon from './Icon';

export default function InputDialog({question,agentName,onSubmit,onClose}){
 const dialog=useRef(null),[answer,setAnswer]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 useEffect(()=>{const el=dialog.current;el.showModal();return()=>{if(el.open)el.close()}},[]);
 async function submit(e){e.preventDefault();if(!answer.trim()||busy)return;setBusy(true);setError('');try{await onSubmit(answer.trim());onClose()}catch(err){setError(err.message);setBusy(false)}}
 return <dialog ref={dialog} className="input-dialog" onCancel={e=>{if(busy)e.preventDefault();else onClose()}} aria-labelledby="input-title">
  <form onSubmit={submit}><span className="agent-icon"><Icon name="clock"/></span><h2 id="input-title">A quick question from {agentName}</h2><p>{question}</p>
  <label>Your answer<textarea autoFocus maxLength={8000} rows={4} required value={answer} onChange={e=>setAnswer(e.target.value)} disabled={busy}/></label>
  <p className="privacy-hint">The workflow is saved. You can close this and answer later.</p>{error&&<p role="alert" className="error">{error}</p>}
  <div className="modal-actions"><button type="button" className="secondary" disabled={busy} onClick={onClose}>Answer later</button><button className="primary" disabled={busy||!answer.trim()}>{busy?'Resuming…':'Resume agent'}<Icon name="chevron" size={14}/></button></div>
  </form></dialog>
}
