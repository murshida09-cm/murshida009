import React, { useState } from "react";
import Brand from "./Brand";
import Icon from "./Icon";
import UIConfig from "../config/UIConfig";
import { login, signup } from "../api/client";
export default function LoginPage({ onAuthenticated }) {
  const [mode, setMode] = useState("login"),
    [form, setForm] = useState({
      first_name: "",
      last_name: "",
      email: "",
      password: "",
    }),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  async function submit(e) {
     e.preventDefault();
  setBusy(true);
  setError("");
  try {
    await onAuthenticated(); // skips login/signup API calls
  } catch (err) {
    setError(err.message);
  } finally {
    setBusy(false);
  }
  }
  return (
    <div className="login-page">
      <section className="login-story">
        <Brand />
        <div className="login-copy">
          <span className="eyebrow">{UIConfig.login.eyebrow}</span>
          <h1>{UIConfig.login.title}</h1>
          <p>{UIConfig.login.description}</p>
          <div className="login-orbit">
            <span className="hero-symbol">
              <Icon name="spark" size={50} />
            </span>
          </div>
          <div className="trust-row">
            <span>
              <Icon name="lock" size={16} />
              Token authentication
            </span>
            <span>
              <Icon name="shield" size={16} />
              Role-based access
            </span>
          </div>
        </div>
      </section>
      <section className="login-form-area">
        <form className="login-form" onSubmit={submit}>
          <Brand compact />
          <h2>
            {mode === "login"
              ? UIConfig.login.signInTitle
              : UIConfig.login.signUpTitle}
          </h2>
          <p>
            {mode === "login"
              ? UIConfig.login.signInText
              : UIConfig.login.signUpText}
          </p>
          {mode === "signup" && (
            <div className="form-row">
              <label>
                First name
                <input
                  name="first_name"
                  required
                  value={form.first_name}
                  onChange={change}
                />
              </label>
              <label>
                Last name
                <input
                  name="last_name"
                  required
                  value={form.last_name}
                  onChange={change}
                />
              </label>
            </div>
          )}
          <label>
            Email address
            <input
              name="email"
              type="email"
              autoComplete="email"
              required
              value={form.email}
              onChange={change}
            />
          </label>
          <label>
            Password
            <input
              name="password"
              type="password"
              autoComplete={
                mode === "login" ? "current-password" : "new-password"
              }
              minLength="6"
              required
              value={form.password}
              onChange={change}
            />
          </label>
          {error && (
            <p className="error" role="alert">
              {error}
            </p>
          )}
          <button className="primary wide" disabled={busy}>
            {busy
              ? "Please wait..."
              : mode === "login"
                ? "Sign in"
                : "Create account"}
            <Icon name="chevron" size={16} />
          </button>
          <button
            type="button"
            className="auth-switch"
            onClick={() => {
              setMode(mode === "login" ? "signup" : "login");
              setError("");
            }}
          >
            {mode === "login"
              ? "New here? Create an account"
              : "Already have an account? Sign in"}
          </button>
        </form>
      </section>
    </div>
  );
}
