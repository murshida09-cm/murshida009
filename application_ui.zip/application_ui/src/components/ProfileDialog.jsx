import React,{useEffect,useRef,useState} from 'react';
import Icon from './Icon';
export default function ProfileDialog({onSubmit,onClose}){
 const ref=useRef(null),[form,setForm]=useState({policy:'Term Life Insurance',age:'',salary:'',goal:'',jurisdiction:''});
 useEffect(()=>{ref.current.showModal()},[]);
 const field=(key,label,type='text')=><label>{label}<input type={type} min={type==='number'?18:undefined} max={type==='number'?100:undefined} maxLength={300} value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})}/></label>;
 return <dialog ref={ref} className="input-dialog" onCancel={onClose} aria-labelledby="profile-title"><form onSubmit={e=>{e.preventDefault();onSubmit(Object.fromEntries(Object.entries(form).filter(([,v])=>v.trim())));onClose()}}>
 <span className="agent-icon"><Icon name="spark"/></span><h2 id="profile-title">Let's make it personal.</h2><p>Share what you know. Agents can ask for essential missing details later.</p>
 <label>Policy type<select value={form.policy} onChange={e=>setForm({...form,policy:e.target.value})}>{['Term Life Insurance','Health Insurance','Child Plan','Retirement Plan','Investment Linked Plan','Travel Insurance'].map(v=><option key={v}>{v}</option>)}</select></label>
 <div className="form-row">{field('age','Age (optional)','number')}{field('salary','Annual salary range (optional)')}</div>{field('goal','Your coverage priority (optional)')}{field('jurisdiction','Country / jurisdiction (optional)')}
 <p className="privacy-hint">Details are sent to the backend and configured Azure model. Use fictional data while developing.</p>
 <div className="modal-actions"><button type="button" className="secondary" onClick={onClose}>Not now</button><button className="primary">Create my policy brief<Icon name="chevron" size={14}/></button></div>
 </form></dialog>
}
