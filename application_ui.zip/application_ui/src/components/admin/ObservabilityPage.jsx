import React, { useCallback, useEffect, useMemo, useState } from 'react';
import Icon from '../Icon';
import PageHeader from './PageHeader';
import SessionDialog from './SessionDialog';
import UIConfig from '../../config/UIConfig';
import { request } from '../../api/client';
import { aggregate, currentMonthValue, fmtCompact, fmtCost, fmtTokens, toApiMonth, toList } from '../../utils/usage';

const T = UIConfig.observability;
const Cost = ({ b }) => <span className={b.unpriced ? 'cost-warn' : ''} title={b.unpriced ? T.unpriced : undefined}>{fmtCost(b.cost)}{b.unpriced && ' *'}</span>;

function KpiCard({ icon, label, value, tone, children }) {
  return (
    <article className={'kpi-card tone-' + tone}>
      <div className="kpi-top"><span className="kpi-icon"><Icon name={icon} size={20} /></span><span className="kpi-label">{label}</span></div>
      <strong className="kpi-value">{value}</strong>
      {children && <div className="kpi-foot">{children}</div>}
    </article>
  );
}

function UserRow({ u, totalCost, expanded, onToggle, onSessions }) {
  const share = totalCost > 0 ? (u.cost / totalCost) * 100 : 0;
  return (
    <>
      <tr className={'user-row' + (expanded ? ' expanded' : '')} onClick={onToggle}>
        <td>
          <button type="button" className="expander" aria-expanded={expanded} aria-label={`Toggle ${u.user}`} onClick={e => { e.stopPropagation(); onToggle(); }}>
            <Icon name="chevdown" size={16} className={'caret ' + (expanded ? 'open' : '')} />
          </button>
        </td>
        <td><span className="user-cell"><span className="table-avatar">{String(u.user).slice(0, 2).toUpperCase()}</span><span><strong>{u.user}</strong><small>{u.sessions.length} session{u.sessions.length === 1 ? '' : 's'} · {u.models.length} model{u.models.length === 1 ? '' : 's'}</small></span></span></td>
        <td className="num mono">{fmtTokens(u.input)}</td>
        <td className="num mono">{fmtTokens(u.output)}</td>
        <td className="num mono">{fmtTokens(u.input + u.output)}</td>
        <td className="num"><div className="cost-cell"><strong className="mono"><Cost b={u} /></strong><span className="share-bar"><i style={{ width: `${Math.min(share, 100)}%` }} /></span></div></td>
      </tr>
      {expanded && (
        <tr className="detail-row">
          <td />
          <td colSpan="5">
            <div className="detail-panel">
              <div className="detail-head"><h3>Usage by LLM model</h3>
                <button type="button" className="secondary compact-btn" onClick={() => onSessions(u)}><Icon name="clock" size={15} />{T.sessionButton} ({u.sessions.length})</button>
              </div>
              <table className="data-table compact">
                <thead><tr><th>LLM model</th><th className="num">Input tokens</th><th className="num">Output tokens</th><th className="num">Cost</th><th className="num">Share of user cost</th></tr></thead>
                <tbody>
                  {u.models.map(m => (
                    <tr key={m.llm}>
                      <td><span className="model-chip"><Icon name="token" size={14} />{m.llm}</span></td>
                      <td className="num mono">{fmtTokens(m.input)}</td>
                      <td className="num mono">{fmtTokens(m.output)}</td>
                      <td className="num mono"><Cost b={m} /></td>
                      <td className="num">{u.cost > 0 ? `${((m.cost / u.cost) * 100).toFixed(1)}%` : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

export default function ObservabilityPage() {
  const [month, setMonth] = useState(currentMonthValue());
  const [rows, setRows] = useState([]);
  const [prices, setPrices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [userFilter, setUserFilter] = useState('');
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState(() => new Set());
  const [sessionUser, setSessionUser] = useState(null);
  const apiMonth = toApiMonth(month);

  const load = useCallback(async () => {
    if (!apiMonth) return;
    setLoading(true); setError(''); setExpanded(new Set());
    try {
      const [priceData, usageData] = await Promise.all([
        request(UIConfig.api.getPriceCard),
        request(`${UIConfig.api.observabilityData}?month=${encodeURIComponent(apiMonth)}`),
      ]);
      setPrices(toList(priceData)); setRows(toList(usageData));
    } catch (e) { setError(e.message); setRows([]); }
    finally { setLoading(false); }
  }, [apiMonth]);
  useEffect(() => { load(); }, [load]);

  const data = useMemo(() => aggregate(rows, prices), [rows, prices]);
  const visible = data.users.filter(u => (!userFilter || u.user === userFilter) && (!search || u.user.toLowerCase().includes(search.toLowerCase())));
  const toggle = name => setExpanded(s => { const n = new Set(s); n.has(name) ? n.delete(name) : n.add(name); return n; });
  const t = data.totals;
  const monthLabel = new Date(`${month}-01T00:00:00`).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <div className="admin-page wide-page">
      <PageHeader icon="chart" title={T.title} description={T.description} />

      <div className="filter-bar">
        <label className="month-field"><span><Icon name="calendar" size={16} />{T.monthLabel}</span>
          <input type="month" value={month} max={currentMonthValue()} onChange={e => e.target.value && setMonth(e.target.value)} />
        </label>
        <span className="filter-chip">{apiMonth}</span>
        <button type="button" className="ghost compact-btn" onClick={load} disabled={loading}><Icon name="refresh" size={15} />Refresh</button>
      </div>

      {error && <div className="banner error" role="alert"><Icon name="close" size={16} />{error}</div>}
      {!loading && data.unpricedModels.length > 0 && (
        <div className="banner warn"><Icon name="tag" size={16} />No price configured for: <strong>{data.unpricedModels.join(', ')}</strong>. Their cost is excluded and marked with *.</div>
      )}

      <section className={'kpi-grid' + (loading ? ' is-loading' : '')}>
        <KpiCard icon="users" tone="blue" label={T.cards.users} value={fmtTokens(data.userCount)}><span>Active in {monthLabel}</span></KpiCard>
        <KpiCard icon="agent" tone="violet" label={T.cards.agents} value={fmtTokens(data.agentCount)}><span>Distinct agents invoked</span></KpiCard>
        <KpiCard icon="token" tone="teal" label={T.cards.tokens} value={fmtCompact(t.input + t.output)}>
          <span className="split"><small>Input</small><b>{fmtTokens(t.input)}</b></span><span className="split"><small>Output</small><b>{fmtTokens(t.output)}</b></span>
        </KpiCard>
        <KpiCard icon="coin" tone="amber" label={T.cards.cost} value={fmtCost(t.cost, 2)}><span>{UIConfig.currency.code} · based on current price card</span></KpiCard>
      </section>

      <div className="data-card">
        <div className="data-card-head">
          <div><h2>{T.userSection}</h2><small>{visible.length} of {data.users.length} users</small></div>
          <div className="toolbar">
            <div className="search-field"><Icon name="search" size={15} /><input placeholder="Search user..." value={search} onChange={e => setSearch(e.target.value)} aria-label="Search user" /></div>
            <select value={userFilter} onChange={e => setUserFilter(e.target.value)} aria-label={T.userFilter}>
              <option value="">{T.allUsers}</option>
              {data.users.map(u => <option key={u.user} value={u.user}>{u.user}</option>)}
            </select>
          </div>
        </div>
        {loading ? <div className="loading"><span className="spinner" />Loading usage for {apiMonth}...</div> : (
          <div className="table-wrap">
            <table className="data-table user-table">
              <thead><tr><th className="exp-col" /><th>User</th><th className="num">Input tokens</th><th className="num">Output tokens</th><th className="num">Total tokens</th><th className="num">Total cost</th></tr></thead>
              <tbody>
                {visible.map(u => <UserRow key={u.user} u={u} totalCost={t.cost} expanded={expanded.has(u.user)} onToggle={() => toggle(u.user)} onSessions={setSessionUser} />)}
                {!visible.length && <tr><td colSpan="6" className="empty-cell">{data.users.length ? 'No users match the filter.' : T.empty}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {sessionUser && <SessionDialog user={sessionUser} month={apiMonth} onClose={() => setSessionUser(null)} />}
    </div>
  );
}
