import React from 'react';
import Icon from '../Icon';
export default function ConfirmDialog({ title, message, confirmLabel = 'Delete', busy, onConfirm, onCancel }) {
  return (
    <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget && !busy) onCancel(); }}>
      <div className="modal confirm-modal" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title">
        <span className="confirm-icon"><Icon name="trash" /></span>
        <h2 id="confirm-title">{title}</h2>
        <p>{message}</p>
        <div className="modal-actions">
          <button type="button" className="secondary" disabled={busy} onClick={onCancel}>Cancel</button>
          <button type="button" className="danger" disabled={busy} onClick={onConfirm}>{busy ? 'Deleting...' : confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}
