import React, { useEffect, useState } from 'react';
import Icon from '../Icon';
import UIConfig from '../../config/UIConfig';
import { fmtCost, fmtTokens } from '../../utils/usage';

const T = UIConfig.observability;
const Cost = ({ b }) => <span className={b.unpriced ? 'cost-warn' : ''} title={b.unpriced ? T.unpriced : undefined}>{fmtCost(b.cost)}{b.unpriced && ' *'}</span>;

export default function SessionDialog({ user, month, onClose }) {
  const [open, setOpen] = useState(() => new Set(user.sessions.length === 1 ? [user.sessions[0].session_id] : []));
  const toggle = id => setOpen(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });
  useEffect(() => { const esc = e => e.key === 'Escape' && onClose(); document.addEventListener('keydown', esc); return () => document.removeEventListener('keydown', esc); }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal session-modal" role="dialog" aria-modal="true" aria-labelledby="session-title">
        <header className="session-modal-head">
          <div>
            <span className="eyebrow">{month}</span>
            <h2 id="session-title">{T.sessionTitle} · {user.user}</h2>
            <p>{user.sessions.length} session{user.sessions.length === 1 ? '' : 's'} · {fmtTokens(user.input + user.output)} tokens · <Cost b={user} /></p>
          </div>
          <button type="button" className="icon-btn" aria-label="Close" onClick={onClose}><Icon name="close" /></button>
        </header>
        <div className="session-list">
          {user.sessions.map((s, i) => {
            const isOpen = open.has(s.session_id);
            return (
              <section key={s.session_id} className={'session-item' + (isOpen ? ' open' : '')}>
                <button type="button" className="session-row" aria-expanded={isOpen} onClick={() => toggle(s.session_id)}>
                  <Icon name="chevdown" size={16} className={'caret ' + (isOpen ? 'open' : '')} />
                  <span className="session-id"><small>Session {user.sessions.length - i}</small><code title={s.session_id}>{s.session_id}</code></span>
                  <span className="session-stat"><small>Agents</small>{s.agentCount}</span>
                  <span className="session-stat"><small>Input</small>{fmtTokens(s.input)}</span>
                  <span className="session-stat"><small>Output</small>{fmtTokens(s.output)}</span>
                  <span className="session-stat strong"><small>Cost</small><Cost b={s} /></span>
                </button>
                {isOpen && (
                  <div className="table-wrap nested">
                    <table className="data-table compact">
                      <thead><tr><th>Agent</th><th>LLM model</th><th className="num">Input tokens</th><th className="num">Output tokens</th><th className="num">Cost</th></tr></thead>
                      <tbody>
                        {s.lines.map(l => (
                          <tr key={l.agent + l.llm}>
                            <td><span className="agent-chip"><Icon name="agent" size={14} />{l.agent}</span></td>
                            <td><span className="model-chip">{l.llm}</span></td>
                            <td className="num mono">{fmtTokens(l.input)}</td>
                            <td className="num mono">{fmtTokens(l.output)}</td>
                            <td className="num mono"><Cost b={l} /></td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot><tr><td colSpan="2">Session total</td><td className="num mono">{fmtTokens(s.input)}</td><td className="num mono">{fmtTokens(s.output)}</td><td className="num mono"><Cost b={s} /></td></tr></tfoot>
                    </table>
                  </div>
                )}
              </section>
            );
          })}
        </div>
      </div>
    </div>
  );
}
