import React from 'react';
import Icon from '../Icon';
export default function PageHeader({ icon, title, description, actions }) {
  return (
    <div className="page-heading">
      <span className="page-icon"><Icon name={icon} /></span>
      <div className="page-heading-text"><span className="eyebrow">ADMINISTRATION</span><h1>{title}</h1><p>{description}</p></div>
      {actions && <div className="page-actions">{actions}</div>}
    </div>
  );
}
