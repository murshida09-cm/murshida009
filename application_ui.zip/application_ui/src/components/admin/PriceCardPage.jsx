import React, { useCallback, useEffect, useState } from 'react';
import Icon from '../Icon';
import PageHeader from './PageHeader';
import ConfirmDialog from './ConfirmDialog';
import UIConfig from '../../config/UIConfig';
import { request } from '../../api/client';
import { fmtCost, modelKey, toList } from '../../utils/usage';

const T = UIConfig.priceCard;
const EMPTY = { llm: '', input_rate: '', output_rate: '' };

function validate(form, rows, editingId) {
  const errors = {};
  const name = form.llm.trim();
  if (!name) errors.llm = 'Model name is required.';
  else if (rows.some(r => r.mpc_seq_id !== editingId && modelKey(r.llm) === modelKey(name))) errors.llm = 'This model already exists.';
  for (const key of ['input_rate', 'output_rate']) {
    const raw = String(form[key]).trim();
    if (raw === '') errors[key] = 'Required.';
    else if (!Number.isFinite(Number(raw)) || Number(raw) < 0) errors[key] = 'Enter a valid non-negative amount.';
  }
  return errors;
}

function EditRow({ form, setForm, errors, busy, onSave, onCancel, isNew }) {
  const set = key => e => setForm(f => ({ ...f, [key]: e.target.value }));
  const keys = e => { if (e.key === 'Enter') onSave(); if (e.key === 'Escape') onCancel(); };
  return (
    <tr className={'edit-row' + (isNew ? ' new' : '')}>
      <td>
        <input autoFocus aria-label={T.modelLabel} placeholder="e.g. GPT-4.1" value={form.llm} onChange={set('llm')} onKeyDown={keys} className={errors.llm ? 'invalid' : ''} />
        {errors.llm && <small className="field-error">{errors.llm}</small>}
      </td>
      {['input_rate', 'output_rate'].map(k => (
        <td key={k} className="num">
          <div className={'money-input' + (errors[k] ? ' invalid' : '')}>
            <span>{UIConfig.currency.symbol}</span>
            <input type="number" min="0" step="0.0001" inputMode="decimal" aria-label={k === 'input_rate' ? T.inputLabel : T.outputLabel} placeholder="0.00" value={form[k]} onChange={set(k)} onKeyDown={keys} />
          </div>
          {errors[k] && <small className="field-error">{errors[k]}</small>}
        </td>
      ))}
      <td className="row-actions">
        <button type="button" className="primary compact-btn" disabled={busy} onClick={onSave}><Icon name="check" size={15} />{busy ? 'Saving...' : 'Save'}</button>
        <button type="button" className="ghost compact-btn" disabled={busy} onClick={onCancel}>Cancel</button>
      </td>
    </tr>
  );
}

export default function PriceCardPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // mpc_seq_id | 'new' | null
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [toDelete, setToDelete] = useState(null);
  const [message, setMessage] = useState(null); // {type,text}

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows(toList(await request(UIConfig.api.getPriceCard)).sort((a, b) => String(a.llm).localeCompare(String(b.llm)))); }
    catch (e) { setMessage({ type: 'error', text: e.message }); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const startAdd = () => { setEditing('new'); setForm(EMPTY); setErrors({}); setMessage(null); };
  const startEdit = row => { setEditing(row.mpc_seq_id); setForm({ llm: row.llm, input_rate: String(row.input_rate), output_rate: String(row.output_rate) }); setErrors({}); setMessage(null); };
  const cancel = () => { setEditing(null); setErrors({}); };

  async function save() {
    const id = editing === 'new' ? null : editing;
    const errs = validate(form, rows, id);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const body = { llm: form.llm.trim(), input_rate: Number(form.input_rate), output_rate: Number(form.output_rate) };
    setBusy(true);
    try {
      if (id === null) await request(UIConfig.api.addPriceCard, body);
      else await request(UIConfig.api.updatePriceCard, { mpc_seq_id: id, ...body });
      setMessage({ type: 'success', text: `${body.llm} pricing ${id === null ? 'added' : 'updated'}.` });
      setEditing(null);
      await load();
    } catch (e) { setMessage({ type: 'error', text: e.message }); }
    finally { setBusy(false); }
  }

  async function confirmDelete() {
    setBusy(true);
    try {
      await request(UIConfig.api.deletePriceCard, { mpc_seq_id: toDelete.mpc_seq_id });
      setMessage({ type: 'success', text: `${toDelete.llm} removed.` });
      setToDelete(null);
      await load();
    } catch (e) { setMessage({ type: 'error', text: e.message }); setToDelete(null); }
    finally { setBusy(false); }
  }

  const editProps = { form, setForm, errors, busy, onSave: save, onCancel: cancel };

  return (
    <div className="admin-page">
      <PageHeader icon="tag" title={T.title} description={T.description}
        actions={<button type="button" className="primary" disabled={editing !== null} onClick={startAdd}><Icon name="plus" size={16} />{T.addModel}</button>} />
      {message && <div className={'banner ' + message.type} role="status"><Icon name={message.type === 'error' ? 'close' : 'check'} size={16} />{message.text}</div>}

      <div className="data-card">
        <div className="data-card-head">
          <div><h2>Configured models</h2><small>{rows.length} model{rows.length === 1 ? '' : 's'} · {UIConfig.currency.code} per 1M tokens</small></div>
        </div>
        {loading ? <div className="loading"><span className="spinner" />Loading price card...</div> : (
          <div className="table-wrap">
            <table className="data-table price-table">
              <thead><tr><th>{T.modelLabel}</th><th className="num">{T.inputLabel}</th><th className="num">{T.outputLabel}</th><th className="actions-col" /></tr></thead>
              <tbody>
                {editing === 'new' && <EditRow isNew {...editProps} />}
                {rows.map(row => editing === row.mpc_seq_id ? <EditRow key={row.mpc_seq_id} {...editProps} /> : (
                  <tr key={row.mpc_seq_id}>
                    <td><span className="model-chip"><Icon name="token" size={15} />{row.llm}</span></td>
                    <td className="num mono">{fmtCost(row.input_rate)}</td>
                    <td className="num mono">{fmtCost(row.output_rate)}</td>
                    <td className="row-actions">
                      <button type="button" className="icon-btn" title="Edit" aria-label={`Edit ${row.llm}`} disabled={editing !== null} onClick={() => startEdit(row)}><Icon name="pen" size={16} /></button>
                      <button type="button" className="icon-btn danger-text" title="Delete" aria-label={`Delete ${row.llm}`} disabled={editing !== null} onClick={() => setToDelete(row)}><Icon name="trash" size={16} /></button>
                    </td>
                  </tr>
                ))}
                {!rows.length && editing !== 'new' && <tr><td colSpan="4" className="empty-cell">{T.empty}</td></tr>}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {toDelete && <ConfirmDialog title={`Delete ${toDelete.llm}?`} message={T.deleteConfirm} busy={busy} onConfirm={confirmDelete} onCancel={() => setToDelete(null)} />}
    </div>
  );
}
