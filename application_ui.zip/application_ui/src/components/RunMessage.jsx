import React,{useEffect,useState} from 'react';
import ReactMarkdown from 'react-markdown';
import useRunStream from '../hooks/useRunStream';
import AgentTree from './AgentTree';
import InputDialog from './InputDialog';
import ResponseActions from './ResponseActions';
import Icon from './Icon';
import UIConfig from '../config/UIConfig';

function download(text){const url=URL.createObjectURL(new Blob([text],{type:'text/markdown;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='AI-response.md';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
export default function RunMessage({runId,at,onStatus,onRefine}){
 const {run,connection,resume,retry,reconnect}=useRunStream(runId);
 const [dialog,setDialog]=useState(false),[dismissed,setDismissed]=useState(null),[actionError,setActionError]=useState('');
 const pending=run.pending[0],done=run.status==='completed',stopped=['completed','error','paused'].includes(run.status);
 useEffect(()=>{onStatus(runId,run.status)},[runId,run.status,onStatus]);
 useEffect(()=>{if(pending&&pending.interrupt_id!==dismissed)setDialog(true)},[pending?.interrupt_id,dismissed]);
 const close=()=>{setDismissed(pending?.interrupt_id);setDialog(false)};
 async function doRetry(){try{setActionError('');await retry()}catch(e){setActionError(e.message)}}
 return <div className={'message assistant '+(run.mode==='workflow'?'ag-message':'')}>
 <img className="message-avatar" src="/agent.svg" alt={UIConfig.chat.assistantName}/>
 <div className={'message-body '+(run.mode==='workflow'?'ag-card '+(done?'is-done':stopped?'is-stopped':'is-live'):'live-chat-body')}>
 <div className="ag-head"><span className="message-author">{UIConfig.chat.assistantName}<small>{UIConfig.chat.assistantSubtitle}</small></span><time className="ag-time">{new Date(at).toLocaleTimeString([],{hour:'numeric',minute:'2-digit'})}</time></div>
 {run.mode==='workflow'&&<><p className="ag-lead">{done?'Your illustrative policy brief is ready.':run.status==='paused'?'A little input will help me continue.':run.status==='error'?'The workflow stopped.':'I’m working on it.'}</p>
 <div className="ag-flow"><div className="ag-orch"><span className="ag-orch-icon"><Icon name={done?'check':'orch'} size={18}/></span><span className="ag-orch-text"><strong>Orchestrator</strong><span className="ag-sep">·</span><b>{done?'Completed':run.status==='paused'?'Paused':run.status==='error'?'Stopped':'Running'}</b> <span className="ag-muted">{run.orchestrator}</span></span>{!stopped?<span className="ag-spin"/>:done?<span className="ag-check"><Icon name="check" size={12}/></span>:<Icon name="clock" size={16}/>} {!stopped&&<span className="ag-orch-bar"/>}</div><AgentTree run={run} onAnswer={()=>setDialog(true)}/></div></>}
 {!run.mode&&<p className="typing">Understanding your request<span>…</span></p>}
 {run.answer&&<div className={run.mode==='workflow'?'inline-brief streamed-answer':'bubble streamed-answer'}><ReactMarkdown skipHtml components={{a:({node,...props})=><a {...props} target="_blank" rel="noopener noreferrer"/>}}>{run.answer}</ReactMarkdown></div>}
 {done&&run.mode==='workflow'&&<div className="brief-actions"><button type="button" className="secondary" onClick={()=>download(run.answer)}><Icon name="download" size={14}/>Download brief</button><button type="button" className="text-button" onClick={onRefine||(()=>{})}>Refine details<Icon name="chevron" size={13}/></button></div>}
 {run.status==='paused'&&<button type="button" className="inline-action" onClick={()=>setDialog(true)}>Answer {run.agents.find(a=>a.id===pending?.agent_id)?.name||'agent'}’s question</button>}
 {run.error&&<div className="run-error" role="alert">{run.error}<button type="button" className="secondary" onClick={doRetry}>Retry from checkpoint</button></div>}
 {actionError&&<p role="alert" className="error">{actionError}</p>}
 {['reconnecting','offline'].includes(connection)&&<div className="connection-note" role="status">{connection==='offline'?'Connection lost. Your run continues on the server.':'Reconnecting to live updates…'}<button type="button" className="text-button" onClick={reconnect}>Reconnect</button></div>}
 {(run.answer||stopped)&&<ResponseActions storageKey={'insura-feedback-'+runId} text={run.answer||run.orchestrator} stamp={done?'Completed':run.status==='paused'?'Input needed':'Live'}/>}
 {dialog&&pending&&<InputDialog key={pending.interrupt_id} question={pending.question} agentName={run.agents.find(a=>a.id===pending.agent_id)?.name||pending.agent_id} onSubmit={answer=>resume(pending.interrupt_id,answer)} onClose={close}/>}
 </div></div>
}
