import React, { useCallback, useEffect, useRef, useState } from "react";
import SpeechRecognition, {
  useSpeechRecognition,
} from "react-speech-recognition";
import RunMessage from "./RunMessage";
import Icon from "./Icon";
import UIConfig from "../config/UIConfig";
import { request } from "../api/client";
const STORAGE = "ai-workspace-chat-sessions";
const load = () => {
  try {
    return JSON.parse(localStorage.getItem(STORAGE)) || [];
  } catch {
    return [];
  }
};
export default function ChatWidget({ open, onClose }) {
  const [sessions, setSessions] = useState(load),
    [active, setActive] = useState(null),
    [input, setInput] = useState(""),
    [error, setError] = useState(""),
    [sending, setSending] = useState(false),
    [statuses, setStatuses] = useState({});
  const bottom = useRef();
  const current = sessions.find((s) => s.id === active);
  const last = current?.messages.filter((m) => m.role === "assistant").at(-1);
  const busy =
    last &&
    ["queued", "running", "paused"].includes(
      statuses[last.runId] || last.status || "queued",
    );
  const {
    transcript,
    listening,
    resetTranscript,
    isMicrophoneAvailable,
    browserSupportsSpeechRecognition,
  } = useSpeechRecognition();
  const baseText = useRef("");

  useEffect(() => {
    if (listening) setInput(`${baseText.current} ${transcript}`.trim());
  }, [transcript, listening]);

  useEffect(() => {
    if (!open || busy || sending) SpeechRecognition.stopListening();
  }, [open, busy, sending]);
  useEffect(() => {
    localStorage.setItem(STORAGE, JSON.stringify(sessions));
  }, [sessions]);
  useEffect(() => {
    if (open) bottom.current?.scrollIntoView({ block: "end" });
  }, [open, current?.messages.length, statuses]);
  const onStatus = useCallback((id, status) => {
    setStatuses((s) => ({ ...s, [id]: status }));
    setSessions((list) =>
      list.map((session) => ({
        ...session,
        messages: session.messages.map((m) =>
          m.runId === id ? { ...m, status } : m,
        ),
      })),
    );
  }, []);
  function newChat() {
    setActive(null);
    setInput("");
    setError("");
  }
  function toggleMic() {
    if (listening) {
      SpeechRecognition.stopListening();
      return;
    }
    if (!isMicrophoneAvailable) {
      setError("Microphone access is blocked. Allow it in your browser settings.");
      return;
    }
    setError("");
    baseText.current = input;
    resetTranscript();
    SpeechRecognition.startListening({ continuous: true, language: "en-IN" });
  }
  async function send(e) {
    e?.preventDefault();
    const value = input.trim();
    if (!value || sending || busy) return;
    SpeechRecognition.stopListening();
    resetTranscript();
    setSending(true);
    setError("");
    const sid = active || crypto.randomUUID(),
      rid = crypto.randomUUID(),
      at = Date.now();
    try {
      await request(UIConfig.api.chatRuns, {
        run_id: rid,
        session_id: sid,
        message: value,
        profile: {},
      });
      setSessions((list) => {
        const existing = list.find((s) => s.id === sid),
          messages = [
            ...(existing?.messages || []),
            { role: "user", text: value, at },
            { role: "assistant", runId: rid, at, status: "queued" },
          ];
        return existing
          ? list.map((s) => (s.id === sid ? { ...s, messages } : s))
          : [{ id: sid, title: value.slice(0, 32), messages }, ...list];
      });
      setActive(sid);
      setInput("");
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  }
  if (!open) return null;
  return (
    <div
      className="chat-overlay"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section className="chat-window" aria-label="AI chat">
        <aside className="chat-side">
          <button className="new-chat" onClick={newChat}>
            <Icon name="plus" /> {UIConfig.chat.newChat}
          </button>
          <div className="history-label">RECENT</div>
          <nav>
            {sessions.map((s) => (
              <button
                key={s.id}
                className={active === s.id ? "selected" : ""}
                onClick={() => setActive(s.id)}
              >
                <Icon name="file" size={15} />
                <span>{s.title}</span>
              </button>
            ))}
          </nav>
        </aside>
        <div className="chat-main">
          <header className="chat-head">
            <div>
              <span className="assistant-icon">
                <Icon name="spark" />
              </span>
              <span>
                <strong>{UIConfig.chat.title}</strong>
                <small>
                  <i /> {UIConfig.chat.subtitle}
                </small>
              </span>
            </div>
            <button className="icon-button" onClick={onClose}>
              <Icon name="close" />
            </button>
          </header>
          <div className="chat-workspace">
            {!current ? (
              <div className="chat-empty">
                <span>
                  <Icon name="spark" size={34} />
                </span>
                <h2>{UIConfig.chat.emptyTitle}</h2>
                <p>{UIConfig.chat.emptyText}</p>
              </div>
            ) : (
              <div className="conversation">
                {current.messages.map((m, i) =>
                  m.role === "user" ? (
                    <div className="message user" key={i}>
                      <div className="message-body">
                        <span className="message-author">You</span>
                        <div className="bubble">{m.text}</div>
                      </div>
                    </div>
                  ) : (
                    <RunMessage
                      key={m.runId}
                      runId={m.runId}
                      at={m.at}
                      onStatus={onStatus}
                    />
                  ),
                )}
                <div ref={bottom} />
              </div>
            )}
          </div>
          <footer className="composer-area">
            {error && <p className="error">{error}</p>}
            <form className="composer" onSubmit={send}>
              <Icon name="spark" size={18} />
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={
                  busy
                    ? "Complete the current workflow first..."
                    : listening
                      ? "Listening..."
                      : UIConfig.chat.placeholder
                }
                disabled={busy || sending}
              />

              {browserSupportsSpeechRecognition && (
                <button
                  type="button"
                  className={`mic-button${listening ? " listening" : ""}`}
                  onClick={toggleMic}
                  disabled={busy || sending}
                  aria-label={listening ? "Stop voice input" : "Start voice input"}
                  aria-pressed={listening}
                >
                  <Icon name={listening ? "stop" : "mic"} />
                </button>

              )}
              <button
                className="send-button"
                disabled={!input.trim() || busy || sending}
              >
                <Icon name="send" />
              </button>
            </form>
            <p className="composer-disclaimer">
              <Icon name="lock" size={11} />
              {UIConfig.chat.disclaimer}
            </p>
          </footer>
        </div>
      </section>
    </div>
  );
}
