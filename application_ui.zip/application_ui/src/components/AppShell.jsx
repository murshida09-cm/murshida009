import React, { useEffect, useRef, useState } from 'react';
import Brand from './Brand';
import Icon from './Icon';
import UIConfig from '../config/UIConfig';

const ADMIN_PAGES = [
  { id: 'users', icon: 'users', label: () => UIConfig.navigation.userManagement, hint: () => UIConfig.navigation.adminDescriptions.users },
  { id: 'priceCard', icon: 'tag', label: () => UIConfig.navigation.priceCard, hint: () => UIConfig.navigation.adminDescriptions.priceCard },
  { id: 'observability', icon: 'chart', label: () => UIConfig.navigation.observability, hint: () => UIConfig.navigation.adminDescriptions.observability },
];
export const ADMIN_PAGE_IDS = ADMIN_PAGES.map(p => p.id);

export default function AppShell({ user, page, setPage, onLogout, children }) {
  const isAdmin = (user?.role || '').toLowerCase() === 'admin';
  const [menu, setMenu] = useState(null); // 'admin' | 'user' | null
  const navRef = useRef(null);

  useEffect(() => {
    const close = e => { if (!navRef.current?.contains(e.target)) setMenu(null); };
    const esc = e => { if (e.key === 'Escape') setMenu(null); };
    document.addEventListener('mousedown', close); document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); };
  }, []);

  const go = id => { setPage(id); setMenu(null); };
  const adminActive = ADMIN_PAGE_IDS.includes(page);
  const initials = `${user?.first_name?.[0] || ''}${user?.last_name?.[0] || ''}` || 'U';

  return (
    <div className="shell">
      <header className="topnav" ref={navRef}>
        <button type="button" className="topnav-brand" onClick={() => go('home')} aria-label={UIConfig.navigation.home}><Brand compact /></button>
        <nav className="topnav-links" aria-label="Main">
          <button type="button" className={page === 'home' ? 'active' : ''} onClick={() => go('home')}><Icon name="home" size={17} />{UIConfig.navigation.home}</button>
          {isAdmin && (
            <div className="dropdown">
              <button type="button" className={adminActive || menu === 'admin' ? 'active' : ''} aria-haspopup="menu" aria-expanded={menu === 'admin'} onClick={() => setMenu(menu === 'admin' ? null : 'admin')}>
                <Icon name="shield" size={17} />{UIConfig.navigation.admin}<Icon name="chevdown" size={15} className={'caret ' + (menu === 'admin' ? 'open' : '')} />
              </button>
              {menu === 'admin' && (
                <div className="dropdown-menu" role="menu">
                  {ADMIN_PAGES.map(p => (
                    <button type="button" role="menuitem" key={p.id} className={page === p.id ? 'selected' : ''} onClick={() => go(p.id)}>
                      <span className="dd-icon"><Icon name={p.icon} size={18} /></span>
                      <span><strong>{p.label()}</strong><small>{p.hint()}</small></span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </nav>
        <div className="topnav-right">
          <span className="topnav-status"><span className="status-dot" />Online</span>
          <div className="dropdown">
            <button type="button" className="user-button" aria-haspopup="menu" aria-expanded={menu === 'user'} onClick={() => setMenu(menu === 'user' ? null : 'user')}>
              <span className="avatar small">{initials.toUpperCase()}</span>
              <span className="user-meta"><strong>{user?.first_name} {user?.last_name}</strong><small>{user?.role}</small></span>
              <Icon name="chevdown" size={15} />
            </button>
            {menu === 'user' && (
              <div className="dropdown-menu right" role="menu">
                <div className="dd-profile"><strong>{user?.first_name} {user?.last_name}</strong><small>{user?.email || user?.role}</small></div>
                <button type="button" role="menuitem" onClick={onLogout}><span className="dd-icon"><Icon name="logout" size={17} /></span><span><strong>{UIConfig.navigation.logout}</strong></span></button>
              </div>
            )}
          </div>
        </div>
      </header>
      <main className="shell-main">{children}</main>
    </div>
  );
}
