import React,{useEffect,useState} from 'react';
import Icon from './Icon';
const LINK_PATH='M10 0V17Q10 28 21 28H33';
function Transient({agent}){
 const [visible,setVisible]=useState(false);
 useEffect(()=>{setVisible(true);const t=setTimeout(()=>setVisible(false),3500);return()=>clearTimeout(t)},[agent.updated]);
 return <span className={'ag-transient '+(visible?'transient-visible':'')}>{agent.status==='running'&&visible?agent.transient:agent.status==='done'?'Completed':agent.status==='paused'?'Your input is needed':''}</span>
}
export default function AgentTree({run,onAnswer}){
 const [expanded,setExpanded]=useState(true);
 const rows=run.agents.map(a=>({...a,state:a.status==='running'?'active':a.status}));
 const completed=rows.filter(r=>r.state==='done').length;
 return <>
 <button type="button" className="ag-todos" aria-expanded={expanded} onClick={()=>setExpanded(v=>!v)}><span className="ag-todos-icon"><Icon name="todos" size={17}/></span><span>{run.planReady?`Created ${rows.length} todos`:`Planning ${rows.length||''} ${rows.length===1?'task':'tasks'}…`}</span><Icon name="chevdown" size={14} className={'ag-chev '+(expanded?'open':'')}/><span className="ag-count">{completed}/{rows.length} done</span></button>
 {expanded&&<ol className="ag-tree" aria-label="Agent activity">{rows.map((row,i)=>{const next=rows[i+1];return <li key={row.id} className={'ag-row '+row.state+' tone-'+row.tone}>
 <svg className="ag-link" width="40" height="76" viewBox="0 0 40 76" aria-hidden="true">{next&&<path className={'ag-trunk '+next.state} d="M10 16V76"/>}<path className="ag-elbow" d={LINK_PATH}/>{row.state==='active'&&<><path className="ag-pulse" pathLength="100" d={LINK_PATH}/><circle className="ag-halo" cx="34" cy="28" r="3.5"/></>}<circle className="ag-node" cx="34" cy="28" r="3"/></svg>
 <span className="ag-icon"><Icon name={row.icon||'spark'} size={16}/></span><span className="ag-name" title={row.task}>{row.name||row.id}</span>
 {row.state==='active'&&<span className="ag-pill">Running<span className="ag-dots" aria-hidden="true"/></span>}
 {row.state==='error'&&<span className="ag-wait">Stopped</span>}
 {row.state==='waiting'&&<span className="ag-wait"><Icon name="clock" size={14}/>Waiting</span>}
 {row.state==='paused'&&<button type="button" className="input-needed" onClick={onAnswer}>Input needed</button>}
 <Transient agent={row}/><span className="ag-right">{row.state==='active'?<span className="ag-spin"/>:row.state==='done'?<span className="ag-check"><Icon name="check" size={12}/></span>:null}</span>
 </li>})}{!rows.length&&<li className="ag-planning"><span className="ag-skeleton"/><span>Orchestrator is planning…</span></li>}</ol>}
 </>
}
