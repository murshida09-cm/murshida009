import React, { useEffect, useState } from 'react';
import LoginPage from './components/LoginPage';
import AppShell, { ADMIN_PAGE_IDS } from './components/AppShell';
import HomePage from './components/HomePage';
import ChatWidget from './components/ChatWidget';
import UserManagementPage from './components/admin/UserManagementPage';
import PriceCardPage from './components/admin/PriceCardPage';
import ObservabilityPage from './components/admin/ObservabilityPage';
import UIConfig from './config/UIConfig';
import { clearToken, getToken, me } from './api/client';

const ADMIN_VIEWS = { users: UserManagementPage, priceCard: PriceCardPage, observability: ObservabilityPage };

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());
  const [page, setPage] = useState('home');
  const [chatOpen, setChatOpen] = useState(false);
  const [error, setError] = useState('');

  async function loadUser() {
    
    setLoading(true); setError('');
    try { setUser(await me()); }
    catch (e) { clearToken(); setUser(null); setError(e.message); }
    finally { setLoading(false); }
  }
  useEffect(() => { if (getToken()) loadUser(); }, []);
  useEffect(() => {
    Object.entries(UIConfig.theme).forEach(([k, v]) => document.documentElement.style.setProperty(`--${k.replace(/[A-Z]/g, m => '-' + m.toLowerCase())}`, v));
  }, []);

  if (loading) return <div className="splash"><span className="spinner" />Loading workspace...</div>;
  if (!user) return <><LoginPage onAuthenticated={loadUser} />{error && <div className="toast">{error}</div>}</>;

  const isAdmin = user.role?.toLowerCase() === 'admin';
  const AdminView = isAdmin && ADMIN_PAGE_IDS.includes(page) ? ADMIN_VIEWS[page] : null;
  const logout = () => { clearToken(); setUser(null); setPage('home'); setChatOpen(false); };

  return (
    <AppShell user={user} page={page} setPage={setPage} onLogout={logout}>
      {AdminView ? <AdminView /> : <HomePage user={user} onOpenChat={() => setChatOpen(true)} />}
      <ChatWidget open={chatOpen} onClose={() => setChatOpen(false)} />
    </AppShell>
  );
}
